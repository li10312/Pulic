import os.path
from tkinter import *
from agents import *
import sys
import random
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
random.seed(0)

class Gui(VacuumEnvironment):
    """This is a two-dimensional GUI environment. Each location may be
    dirty, clean or can have a wall. The user can change these at each step.
    """
    xyis = [(0,0), (0,0)]
    perceptible_distance = 1
    rand_loc = []
    agt_type = 'reflex'

    def __init__(self, root, width=7, height=7, elements=None):
        print("creating xv with width =", width)
        super().__init__(width, height)
        if elements is None:
            elements = ['D', 'W'] # D is Dirt and W is Wall
        self.root = root
        self.create_frames()
        self.create_buttons()
        self.create_walls()
        self.random_location()
        self.elements = elements

    def create_frames(self):
        """Adds frames to the GUI environment."""
        self.frames = []
        for _ in range(self.height):
            frame = Frame(self.root, bg='red')
            frame.pack(side='bottom')
            self.frames.append(frame)

    def create_buttons(self):
        """Adds buttons to the respective frames in the GUI."""
        self.buttons = []
        for frame in self.frames:
            button_row = []
            for _ in range(self.width):
                button = Button(frame, height=3, width=5, padx=2, pady=2)
                button.config(command=lambda btn=button: self.display_element(btn))
                button.pack(side='left')
                button_row.append(button)
            self.buttons.append(button_row)

    def create_walls(self):
        """Creates the outer boundary walls which do not move."""
        for row, button_row in enumerate(self.buttons):
            if row == 0 or row == len(self.buttons) - 1:
                for button in button_row:
                    button.config(bg = 'red', text='W', state='disabled', disabledforeground='black')
            else:
                button_row[0].config(bg = 'red',text='W', state='disabled', disabledforeground='black')
                button_row[len(button_row) - 1].config(bg = 'red',text='W',
                                                       state='disabled', disabledforeground='black')
        # Place the agent in the centre of the grid.
        # self.buttons[3][3].config(bg='green', text='A', state='disabled', disabledforeground='black')

    def display_element(self, button):
        """Show the things on the GUI."""
        txt = button['text']
        if txt != 'A':
            if txt == 'W':
                button.config(bg='grey', text='D')
            elif txt == 'D':
                button.config(bg='white', text='')
            elif txt == '':
                button.config(bg = 'red', text='W')

    def execute_action(self, agent, action):
        """Determines the action the agent performs."""
        xi, yi = self.xyis[self.agents.index(agent)]
        print("agent at location (", xi, yi, ") and action ", action)
        if action == 'Suck':
            dirt_list = self.list_things_at(agent.location, Dirt)
            if dirt_list:
                dirt = dirt_list[0]
                agent.performance += 100
                self.delete_thing(dirt)
                self.buttons[yi][xi].config(text='', state='normal')
                xf, yf = agent.location
                self.buttons[yf][xf].config(
                    text='A', state='disabled', disabledforeground='black')

        else:
            agent.bump = False
            if action == 'TurnRight':
                agent.direction += Direction.R
            elif action == 'TurnLeft':
                agent.direction += Direction.L
            elif action == 'Forward':
                agent.bump = self.move_to(agent, agent.direction.move_forward(agent.location))
                if not agent.bump:
                    self.buttons[yi][xi].config(bg='white', text='', state='normal')
                    xf, yf = agent.location
                    self.buttons[yf][xf].config(
                        bg = 'green', text='A', state='disabled', disabledforeground='black')

        if action != 'NoOp':
            agent.performance -= 1
        performance = 0
        for agt in self.agents:
            performance += agt.performance
        performance_button.config(text= str(agent.performance))

    def read_env(self):
        """Reads the current state of the GUI environment."""
        for j, btn_row in enumerate(self.buttons):
            for i, btn in enumerate(btn_row):
                if (j != 0 and j != len(self.buttons) - 1) and (i != 0 and i != len(btn_row) - 1):
                    
                    agt_loc = [agt.location for agt in self.agents]
                    # print(i, j)
                    if self.some_things_at((i, j)) and (i, j) not in agt_loc:
                        for thing in self.list_things_at((i, j)):
                            self.delete_thing(thing)
                    if btn['text'] == self.elements[0]:
                        self.add_thing(Dirt(), (i, j))
                    elif btn['text'] == self.elements[1]:
                        self.add_thing(Wall(), (i, j))

    def update_env(self):
        """Updates the GUI environment according to the current state."""
        # print(self.x_start, self.y_start)
        # print(self.x_end, self.y_end)
        self.read_env()
        agt0, agt1 = (self.agents[0], self.agents[1])
        # previous_agent_location = agt.location
        # self.xi, self.yi = previous_agent_location
        self.xyis = (agt0.location, agt1.location)
        self.step()
        # xf, yf = agt.location

    def reset_env(self, agt0, agt1):
        """Resets the GUI environment to the initial state."""

        switch_button.config(text='Reflex')
        random.seed(0)
        self.random_location()
        self.read_env()
        for j, btn_row in enumerate(self.buttons):
            for i, btn in enumerate(btn_row):
                if (j != 0 and j != len(self.buttons) - 1) and (i != 0 and i != len(btn_row) - 1):
                    if self.some_things_at((i, j)):
                        for thing in self.list_things_at((i, j)):
                            self.delete_thing(thing)    
                            btn.config(bg = 'white', text='', state='normal')
        self.set_agent(agt0, agt1)

    def set_agent(self, agt0, agt1):
        
        self.add_thing(agt0, location=self.rand_loc[0])
        self.add_thing(agt1, location=self.rand_loc[1])
        
        self.buttons[self.rand_loc[0][1]][self.rand_loc[0][0]].config(bg = 'green', text='A', state='disabled', disabledforeground='black')
        self.buttons[self.rand_loc[1][1]][self.rand_loc[1][0]].config(bg = 'green', text='A', state='disabled', disabledforeground='black')
        
        agt0.location = self.rand_loc[0]
        agt1.location = self.rand_loc[1]

        agt0.direction = Direction("up")
        agt1.direction = Direction("up")

        agt1.id = 1

    def switch_agent(self):
        if self.agt_type == 'reflex':
            self.agt_type = 'rule'
            self.reset_env(RuleBasedAgent(), RuleBasedAgent())
            switch_button.config(text='Rule')
        else:
            self.agt_type = 'reflex'
            self.reset_env(XYReflexAgent(), XYReflexAgent())
            switch_button.config(text='Reflex')

    def random_location(self):
        # print(self.x_start, self.y_start)
        # print(self.x_end, self.y_end)
        self.rand_loc = [self.random_location_inbounds()]
        while self.rand_loc[0][1] > (self.height - 2)//2:
            self.rand_loc = [self.random_location_inbounds()]
        second = self.random_location_inbounds()
        while second in self.rand_loc or second[1] <= (self.height - 2)//2:
            second = self.random_location_inbounds()
        self.rand_loc.append(second)
        # print(self.rand_loc)

    def exist_dirt(self):
        for _ in self.things:
            if isinstance(_, Dirt):
                return True
        return False
    def run_visiable(self, first=True):
        if first == True:
            self.read_env()
        if not self.exist_dirt():
            return
        self.update_env()
        self.root.after(50, lambda: self.run_visiable(first=False))
    def run(self):
        self.read_env()
        while self.exist_dirt():
            self.update_env()
        

    def have_dirt(self, xi, yi):
        if not self.is_inbounds((xi, yi)):
            return False
        if self.buttons[yi][xi]['text'] == 'D':
            return True
        return False

#implement this. Rule is as follows: At each location, agent checks all the neighboring location: If a "Dirty"
# location found, agent goes to that location, otherwise follow similar rules as the XYReflexAgentProgram bellow.

#Implement this: This will be similar to the ReflectAgent bellow.
class RuleBasedAgent(Agent):
    id = 0
    def __init__(self):
        super().__init__(self.XYRuleBasedAgentProgram)
        self.location = (3, 3)
        self.direction = Direction("up")
    
    def turn(self, aim):
        dir = self.direction
        dir_l = [dir.U, dir.R, dir.D, dir.L]
        now = dir_l.index(self.direction.direction)
        want = dir_l.index(aim)
        if now - want < 0:
            return 'TurnRight'
        elif now - want > 0:
            return 'TurnLeft'
        return 'Forward'
    
    def XYRuleBasedAgentProgram(self, percept):
        status, bump = percept
        if status == 'Dirty':
            return 'Suck'
        xi, yi = self.location
        if env.have_dirt(xi, yi+1): 
            if self.id == 0 and self.location[1] + 1 <= (env.height - 2)//2:
                return self.turn(self.direction.U)
            elif self.id == 1:
                return self.turn(self.direction.U)

        if env.have_dirt(xi+1, yi):
            return self.turn(self.direction.R)
        if env.have_dirt(xi, yi-1):
            if self.id == 1 and self.location[1] - 1 > (env.height - 2)//2:
                return self.turn(self.direction.D)
            elif self.id == 0:
                return self.turn(self.direction.D)
        if env.have_dirt(xi-1, yi):
            return self.turn(self.direction.L)
        if status == 'Dirty':
            return 'Suck'

        if bump == 'Bump':
            value = random.choice((1, 2))
        elif self.direction.direction == self.direction.D and self.id == 1 and self.location[1] - 1 <= (env.height - 2)//2:
            value = random.choice((1, 2))
        elif self.direction.direction == self.direction.U and self.id == 0 and self.location[1] + 1 > (env.height - 2)//2:
            value = random.choice((1, 2))
        else:
            value = random.choice((1, 2, 3, 4))  # 1-right, 2-left, others-forward

        if value == 1:
            return 'TurnRight'
        elif value == 2:
            return 'TurnLeft'
        else:
            return 'Forward'




class XYReflexAgent(Agent):
    """The modified SimpleReflexAgent for the GUI environment."""
    id = 0
    def __init__(self):
        super().__init__(self.XYReflexAgentProgram)
        self.location = (3, 3)
        self.direction = Direction("up")

    def XYReflexAgentProgram(self, percept):
        """The modified SimpleReflexAgentProgram for the GUI environment."""
        status, bump = percept
        if status == 'Dirty':
            return 'Suck'
        # print(self.id, self.location, (env.height - 2)//2)
        # print(self.direction.direction , self.direction.D)
        if bump == 'Bump':
            value = random.choice((1, 2))
        elif self.direction.direction == self.direction.D and self.id == 1 and self.location[1] - 1 <= (env.height - 2)//2:
            value = random.choice((1, 2))
        elif self.direction.direction == self.direction.U and self.id == 0 and self.location[1] + 1 > (env.height - 2)//2:
            value = random.choice((1, 2))
        else:
            value = random.choice((1, 2, 3, 4))  # 1-right, 2-left, others-forward

        if value == 1:
            return 'TurnRight'
        elif value == 2:
            return 'TurnLeft'
        else:
            return 'Forward'


# TODO: Check the coordinate system.
# TODO: Give manual choice for agent's location.
if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python xy_vacuum_environment.py n m")
        exit()
    arg_width = int(sys.argv[1])
    arg_height = int(sys.argv[2])
    win = Tk()
    win.title("Vacuum Robot Environment")
    win.geometry("{}x{}".format(arg_width*50, arg_height*65+100))
    win.resizable(False, False)
    frame = Frame(win, bg='black')
    
    global performance_button
    performance_button = Button(frame, text='Performance', height=2,
                         width=10, padx=2, pady=2)
    performance_button.pack(side='left')
    reset_button = Button(frame, text='Reset', height=2,
                          width=6, padx=2, pady=2)
    reset_button.pack(side='left')
    global switch_button
    switch_button = Button(frame, text='Reflex', height=2,
                          width=8, padx=2, pady=2)
    switch_button.pack(side='left')
    next_button = Button(frame, text='Next', height=2,
                         width=6, padx=2, pady=2)
    next_button.pack(side='left')
    run_button = Button(frame, text='Run', height=2,
                         width=6, padx=2, pady=2)
    run_button.pack(side='left')
    frame.pack(side='bottom')
    env = Gui(win, width=arg_width, height=arg_height)

    vacAgent1 = XYReflexAgent()
    vacAgent2 = XYReflexAgent()
    env.set_agent(vacAgent1, vacAgent2)

    next_button.config(command=env.update_env)
    switch_button.config(command=env.switch_agent)
    reset_button.config(command=lambda: env.reset_env(vacAgent1, vacAgent2))
    run_button.config(command=env.run)
    win.mainloop()
